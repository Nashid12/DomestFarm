@echo off
rem ------------------------------------------------------------
rem Batch script to run the DomestiFarm Java Swing application
rem ------------------------------------------------------------

rem Change to the script's directory (project folder)
cd /d "%~dp0"

rem Run the app with the MySQL JDBC driver on the classpath
java -cp ".;mysql-connector-j-8.4.0.jar" DomestiFarmApp

rem Keep the console open to view any output or errors
pause