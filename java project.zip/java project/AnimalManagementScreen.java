// Part 1
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.swing.table.*;

class AnimalManagementScreen extends JFrame {
    private JPanel animalPanel;
    private JPanel animalButtonPanel;
    private JScrollPane scrollPane;
    private JButton addButton;
    private JButton saveButton;
    private java.util.List<JButton> animalButtons = new ArrayList<>();

    public AnimalManagementScreen() {
        setTitle("Animals - DomestiFarm");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Animals", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 28));
        mainPanel.add(titleLabel, BorderLayout.NORTH);
// Part 2
        animalPanel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addButton = new JButton("+Add");
        addButton.setPreferredSize(new Dimension(60, 25));
        topPanel.add(addButton);
        animalPanel.add(topPanel, BorderLayout.NORTH);

        animalButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        scrollPane = new JScrollPane(animalButtonPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        animalPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        saveButton = new JButton("Save");
        bottomPanel.add(saveButton);
        animalPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(animalPanel, BorderLayout.CENTER);
        add(mainPanel);
// Part 3
        addButton.addActionListener(e -> addAnimalButton());
        saveButton.addActionListener(e -> saveAnimalsToFile());

        loadAnimalsFromFile();

        setVisible(true);
    } 
// Part 4
    private void addAnimalButton() {
        String name = JOptionPane.showInputDialog(this, "Enter Animal Name (e.g., Cow, Goat):");
        if (name == null || name.trim().isEmpty()) return;
        String trimmedName = name.trim();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO animal_categories (name) VALUES (?)")) {
            ps.setString(1, trimmedName);
            ps.executeUpdate();
            
            JButton animalBtn = new JButton(trimmedName);
            animalBtn.setPreferredSize(new Dimension(120, 40));
            animalButtons.add(animalBtn);
            animalButtonPanel.add(animalBtn);
            animalButtonPanel.revalidate();
            animalButtonPanel.repaint();

            animalBtn.addActionListener(e -> new AnimalOptionWindow(trimmedName));
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding category: " + ex.getMessage());
        }
    }
// Part 5
    private void saveAnimalsToFile() {
        JOptionPane.showMessageDialog(this, "Animal categories are automatically saved!");
    }

    private void loadAnimalsFromFile() {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name FROM animal_categories")) {
            animalButtonPanel.removeAll();
            animalButtons.clear();
            while (rs.next()) {
                final String animalName = rs.getString("name").trim(); 
                JButton btn = new JButton(animalName);
                btn.setPreferredSize(new Dimension(120, 40));
                animalButtons.add(btn);
                animalButtonPanel.add(btn);
                btn.addActionListener(e -> new AnimalOptionWindow(animalName)); 
            }
            animalButtonPanel.revalidate();
            animalButtonPanel.repaint();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
// Part 6
class AnimalOptionWindow extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private String animalType;
    private java.util.List<AnimalData> animals = new ArrayList<>();

    public AnimalOptionWindow(String animalType) {
        this.animalType = animalType;
        setTitle(animalType + " Management");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Load persisted records matching this specific category profile
        loadAnimalsFromFile();

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addAnimalBtn = new JButton("Add Animal");
        JButton profileBtn = new JButton("Animal Profile");
        topPanel.add(addAnimalBtn);
        topPanel.add(profileBtn);
// Part 7
        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);

        AddAnimalPanel addAnimalPanel = new AddAnimalPanel(animals, this);
        AnimalProfilePanel profilePanel = new AnimalProfilePanel(animals, animalType, this);

        contentPanel.add(addAnimalPanel, "ADD");
        contentPanel.add(profilePanel, "PROFILE");

        add(topPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        addAnimalBtn.addActionListener(e -> cardLayout.show(contentPanel, "ADD"));
        profileBtn.addActionListener(e -> {
            profilePanel.refreshTable();
            cardLayout.show(contentPanel, "PROFILE");
        });

        setVisible(true);
    }

    // Dynamic Persistence Pipeline grouped by Animal Subtype Class
    public void saveAnimalsToFile() {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                // Clear existing for this category
                try (PreparedStatement psDel = conn.prepareStatement("DELETE FROM animals WHERE category_name = ?")) {
                    psDel.setString(1, animalType);
                    psDel.executeUpdate();
                }
                // Insert current list
                try (PreparedStatement psIns = conn.prepareStatement(
                        "INSERT INTO animals (id, name, gender, animal_class, ear_tag, birth_date, color, age, weight, breed, pasture, category_name) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    for (AnimalData d : animals) {
                        psIns.setString(1, d.id);
                        psIns.setString(2, d.name);
                        psIns.setString(3, d.gender);
                        psIns.setString(4, d.animalClass);
                        psIns.setString(5, d.earTag);
                        psIns.setString(6, d.birthDate);
                        psIns.setString(7, d.color);
                        psIns.setString(8, d.age);
                        psIns.setString(9, d.weight);
                        psIns.setString(10, d.breed);
                        psIns.setString(11, d.pasture);
                        psIns.setString(12, animalType);
                        psIns.executeUpdate();
                    }
                }
                conn.commit();
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving animal data to database: " + ex.getMessage());
        }
    }

    private void loadAnimalsFromFile() {
        animals.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM animals WHERE category_name = ?")) {
            ps.setString(1, animalType);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    animals.add(new AnimalData(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("gender"),
                        rs.getString("animal_class"),
                        rs.getString("ear_tag"),
                        rs.getString("birth_date"),
                        rs.getString("color"),
                        rs.getString("age"),
                        rs.getString("weight"),
                        rs.getString("breed"),
                        rs.getString("pasture")
                    ));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
// Part 8
class AddAnimalPanel extends JPanel {
    private java.util.List<AnimalData> animals;
    private AnimalOptionWindow parentWindow;
    private JTextField idField, nameField, genderField, earTagField, birthField,
            colorField, ageField, weightField, breedField, pastureField;
    private JComboBox<String> classBox;

    public AddAnimalPanel(java.util.List<AnimalData> animals, AnimalOptionWindow parentWindow) {
        this.animals = animals;
        this.parentWindow = parentWindow;
        setLayout(null);

        JLabel[] labels = {
            new JLabel("Animal ID:"), new JLabel("Animal Name:"), new JLabel("Gender:"),
            new JLabel("Class:"), new JLabel("Ear Tag:"), new JLabel("Birth Date:"),
            new JLabel("Color:"), new JLabel("Age:"), new JLabel("Weight:"),
            new JLabel("Breed:"), new JLabel("Pasture:")
        };
// Part 9
        idField = new JTextField();
        nameField = new JTextField();
        genderField = new JTextField();
        earTagField = new JTextField();
        birthField = new JTextField();
        colorField = new JTextField();
        ageField = new JTextField();
        weightField = new JTextField();
        breedField = new JTextField();
        pastureField = new JTextField();
        classBox = new JComboBox<>(new String[]{"Mammalia", "Aves"});

        JComponent[] fields = {idField, nameField, genderField, classBox, earTagField,
                               birthField, colorField, ageField, weightField, breedField, pastureField};

        int y = 40;
        for (int i = 0; i < labels.length; i++) {
            labels[i].setBounds(50, y, 120, 25);
            fields[i].setBounds(180, y, 200, 25);
            add(labels[i]);
            add(fields[i]);
            y += 35;
        }

        JButton saveBtn = new JButton("Save");
        saveBtn.setBounds(400, y + 20, 100, 30);
        add(saveBtn);
        saveBtn.addActionListener(e -> saveAnimal());
    }
// Part 10
    private void saveAnimal() {
        if(idField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID and Name fields cannot be empty.");
            return;
        }

        AnimalData d = new AnimalData(
            idField.getText().trim(), nameField.getText().trim(), genderField.getText().trim(),
            (String) classBox.getSelectedItem(), earTagField.getText().trim(),
            birthField.getText().trim(), colorField.getText().trim(), ageField.getText().trim(),
            weightField.getText().trim(), breedField.getText().trim(), pastureField.getText().trim()
        );
        animals.add(d);
        parentWindow.saveAnimalsToFile(); // Commit directly to database
        JOptionPane.showMessageDialog(this, "Animal Added Successfully!");
        clearFields();
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        genderField.setText("");
        earTagField.setText("");
        birthField.setText("");
        colorField.setText("");
        ageField.setText("");
        weightField.setText("");
        breedField.setText("");
        pastureField.setText("");
    }
}
// Part 11
class AnimalProfilePanel extends JPanel {
    private java.util.List<AnimalData> animals;
    private AnimalOptionWindow parentWindow;
    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;
    private JPanel detailPanel;
    private JTextField[] detailFields;
    private JButton editBtn, saveBtn, deleteBtn;
    private String animalType;

    public AnimalProfilePanel(java.util.List<AnimalData> animals, String animalType, AnimalOptionWindow parentWindow) {
        this.animals = animals;
        this.animalType = animalType;
        this.parentWindow = parentWindow;
        setLayout(new BorderLayout());

        JPanel leftPanel = new JPanel(new BorderLayout());
        JPanel searchPanel = new JPanel(new BorderLayout());
        searchField = new JTextField();
        JButton searchIcon = new JButton("🔍");
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchIcon, BorderLayout.EAST);
        leftPanel.add(searchPanel, BorderLayout.NORTH);

        model = new DefaultTableModel(new Object[]{"ID", "Name", "Gender"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        leftPanel.add(scroll, BorderLayout.CENTER);
// Part 12
        detailPanel = new JPanel(new GridLayout(11, 2, 5, 5));
        String[] labels = {"Animal Id","Animal Name","Gender","Class","Ear Tag","Birth Date",
                           "Color","Age","Weight","Breed","Pasture"};
        detailFields = new JTextField[labels.length];
        for (int i = 0; i < labels.length; i++) {
            detailPanel.add(new JLabel(labels[i]));
            detailFields[i] = new JTextField();
            detailFields[i].setEditable(false);
            detailPanel.add(detailFields[i]);
        }

        JPanel bottomPanel = new JPanel(new FlowLayout());
        saveBtn = new JButton("Save");
        deleteBtn = new JButton("Delete");
        editBtn = new JButton("Edit");
        bottomPanel.add(saveBtn);
        bottomPanel.add(deleteBtn);
        bottomPanel.add(editBtn);

        add(leftPanel, BorderLayout.WEST);
        add(detailPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        refreshTable();
// Part 13
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0 && row < animals.size()) {
                    AnimalData d = animals.get(row);
                    fillDetails(d);
                    if (SwingUtilities.isRightMouseButton(e)) showContextMenu(e, d);
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                clearSelections();
            }
        });

        editBtn.addActionListener(e -> setEditable(true));
        saveBtn.addActionListener(e -> saveChanges());
        deleteBtn.addActionListener(e -> deleteAnimal());
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { search(searchField.getText()); }
        });
    }
// Part 14
    public void refreshTable() {
        table.clearSelection();
        model.setRowCount(0);
        for (AnimalData d : animals) {
            model.addRow(new Object[]{d.id, d.name, d.gender});
        }
    }

    private void clearSelections() {
        table.clearSelection();
        for (JTextField f : detailFields) f.setText("");
        setEditable(false);
    }

    private void fillDetails(AnimalData d) {
        String[] vals = {d.id, d.name, d.gender, d.animalClass, d.earTag, d.birthDate,
                         d.color, d.age, d.weight, d.breed, d.pasture};
        for (int i = 0; i < detailFields.length; i++)
            detailFields[i].setText(vals[i]);
    }

    private void setEditable(boolean flag) {
        for (JTextField f : detailFields) f.setEditable(flag);
    }

    private void saveChanges() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= animals.size()) {
            JOptionPane.showMessageDialog(this, "Please select an animal row from the table first.");
            return;
        }
        AnimalData d = animals.get(row);
        d.id = detailFields[0].getText().trim();
        d.name = detailFields[1].getText().trim();
        d.gender = detailFields[2].getText().trim();
        d.animalClass = detailFields[3].getText().trim();
        d.earTag = detailFields[4].getText().trim();
        d.birthDate = detailFields[5].getText().trim();
        d.color = detailFields[6].getText().trim();
        d.age = detailFields[7].getText().trim();
        d.weight = detailFields[8].getText().trim();
        d.breed = detailFields[9].getText().trim();
        d.pasture = detailFields[10].getText().trim();
        
        parentWindow.saveAnimalsToFile(); 
        refreshTable();
        setEditable(false);
        JOptionPane.showMessageDialog(this, "Changes saved successfully!");
    }
// Part 15
    private void deleteAnimal() {
        int row = table.getSelectedRow();
        if (row < 0 || row >= animals.size()) {
            JOptionPane.showMessageDialog(this, "Please select an animal row to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this record?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            animals.remove(row);
            parentWindow.saveAnimalsToFile(); 
            refreshTable();
            clearSelections();
            JOptionPane.showMessageDialog(this, "Animal deleted!");
        }
    }

    private void search(String query) {
        model.setRowCount(0);
        for (AnimalData d : animals) {
            if (d.id.contains(query) ||
                d.name.toLowerCase().contains(query.toLowerCase()) ||
                d.gender.toLowerCase().contains(query.toLowerCase())) {
                model.addRow(new Object[]{d.id, d.name, d.gender});
            }
        }
    }

    private void showContextMenu(MouseEvent e, AnimalData d) {
        JPopupMenu menu = new JPopupMenu();
        JMenuItem openItem = new JMenuItem("Open Records");
        openItem.addActionListener(ev -> new AnimalRecordsWindow(d));
        menu.add(openItem);
        menu.show(table, e.getX(), e.getY());
    }
}

class AnimalRecordsWindow extends JFrame {
    public AnimalRecordsWindow(AnimalData d) {
        setTitle("Animal Records - " + d.name);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new FlowLayout());
        if ("Mammalia".equalsIgnoreCase(d.animalClass))
            panel.add(new JButton("Milk Records"));
        else
            panel.add(new JButton("Egg Records"));
        panel.add(new JButton("Animal Health"));
        panel.add(new JButton("Breeding"));
        add(panel);
        setVisible(true);
    }
}

class AnimalData {
    String id, name, gender, animalClass, earTag, birthDate, color, age, weight, breed, pasture;

    public AnimalData(String id, String name, String gender, String animalClass, String earTag,
                      String birthDate, String color, String age, String weight,
                      String breed, String pasture) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.animalClass = animalClass;
        this.earTag = earTag;
        this.birthDate = birthDate;
        this.color = color;
        this.age = age;
        this.weight = weight;
        this.breed = breed;
        this.pasture = pasture;
    }
}