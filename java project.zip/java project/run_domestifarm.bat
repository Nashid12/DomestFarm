@echo off
rem ------------------------------------------------------------
rem Batch script to run the DomestiFarm Java Swing application
rem ------------------------------------------------------------

rem Change to the project directory (in case the script is invoked elsewhere)
cd /d "%~dp0"

rem Ensure the MySQL JDBC driver is in the classpath and launch the app
java -cp ".;mysql-connector-j-8.4.0.jar" DomestiFarmApp

rem Keep the console window open after execution (useful for seeing any errors)
pause
