-- create_domestifarm_db.sql
-- SQL script to create the DomestiFarm MySQL database and tables

-- 1. Create database (if not exists)
CREATE DATABASE IF NOT EXISTS domestifarm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE domestifarm;

-- 2. users table (replaces users.txt)
CREATE TABLE IF NOT EXISTS users (
    email VARCHAR(150) PRIMARY KEY,
    password VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- 3. employees table (replaces employees.txt)
CREATE TABLE IF NOT EXISTS employees (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender VARCHAR(10),
    contact VARCHAR(50),
    address TEXT,
    user_type VARCHAR(50),
    date_hired VARCHAR(50),
    salary DOUBLE,
    job_title VARCHAR(100),
    password VARCHAR(100)
) ENGINE=InnoDB;

-- 4. animal_categories table (replaces animal_buttons.txt)
CREATE TABLE IF NOT EXISTS animal_categories (
    name VARCHAR(50) PRIMARY KEY
) ENGINE=InnoDB;

-- 5. animals table (replaces <animal>_data.txt)
CREATE TABLE IF NOT EXISTS animals (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    gender VARCHAR(20),
    animal_class VARCHAR(50),
    ear_tag VARCHAR(50),
    birth_date VARCHAR(50),
    color VARCHAR(50),
    age VARCHAR(50),
    weight VARCHAR(50),
    breed VARCHAR(100),
    pasture VARCHAR(100),
    category_name VARCHAR(50),
    FOREIGN KEY (category_name) REFERENCES animal_categories(name)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 6. daily_finance_records table (replaces daily_finance.txt)
CREATE TABLE IF NOT EXISTS daily_finance_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_date VARCHAR(50) NOT NULL,
    type VARCHAR(20) NOT NULL,   -- 'Expense' or 'Sale'
    name VARCHAR(100) NOT NULL,
    expression VARCHAR(200),
    total DOUBLE NOT NULL
) ENGINE=InnoDB;

-- 7. monthly_profits table (replaces monthly_profit.txt)
CREATE TABLE IF NOT EXISTS monthly_profits (
    month VARCHAR(50) PRIMARY KEY,
    expression VARCHAR(200),
    result DOUBLE NOT NULL
) ENGINE=InnoDB;

-- 8. stockfeed_categories table (replaces stock_list.txt)
CREATE TABLE IF NOT EXISTS stockfeed_categories (
    name VARCHAR(50) PRIMARY KEY
) ENGINE=InnoDB;

-- 9. stockfeed_items table (replaces <stock>_items.txt)
CREATE TABLE IF NOT EXISTS stockfeed_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    quantity INT DEFAULT 0,
    FOREIGN KEY (category_name) REFERENCES stockfeed_categories(name)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 10. Optional: Seed default admin user (only if users table is empty)
INSERT INTO users (email, password)
SELECT 'admin@farm.com', 'admin123'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@farm.com');

-- End of script
