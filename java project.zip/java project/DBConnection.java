import java.io.*;
import java.sql.*;
import java.util.Properties;

public class DBConnection {
    private static String dbUrl;
    private static String dbUser;
    private static String dbPassword;

    static {
        Properties props = new Properties();
        try (InputStream in = new FileInputStream("db.properties")) {
            props.load(in);
            dbUrl = props.getProperty("db.url");
            dbUser = props.getProperty("db.user");
            dbPassword = props.getProperty("db.password");
        } catch (IOException e) {
            System.err.println("Warning: db.properties not found, using default XAMPP credentials.");
            dbUrl = "jdbc:mysql://localhost:3306/domestifarm";
            dbUser = "root";
            dbPassword = "";
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found in classpath!", e);
        }
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    public static void initializeDatabase() {
        // Extract server-only URL to create database if it doesn't exist
        String serverUrl = "jdbc:mysql://localhost:3306/";
        String dbName = "domestifarm";
        
        if (dbUrl != null) {
            int lastSlash = dbUrl.lastIndexOf('/');
            if (lastSlash != -1) {
                serverUrl = dbUrl.substring(0, lastSlash + 1);
                dbName = dbUrl.substring(lastSlash + 1);
                int questionMark = dbName.indexOf('?');
                if (questionMark != -1) {
                    dbName = dbName.substring(0, questionMark);
                }
            }
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Error: MySQL JDBC Driver not found in classpath!");
            return;
        }

        // 1. Create database if not exists
        try (Connection conn = DriverManager.getConnection(serverUrl, dbUser, dbPassword);
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + dbName);
            System.out.println("Database " + dbName + " verified/created successfully.");
        } catch (SQLException e) {
            System.err.println("Error creating database: " + e.getMessage());
            e.printStackTrace();
        }

        // 2. Create tables
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // users table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                    "email VARCHAR(150) PRIMARY KEY, " +
                    "password VARCHAR(100) NOT NULL" +
                    ")");

            // employees table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS employees (" +
                    "id VARCHAR(50) PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "age INT, " +
                    "gender VARCHAR(10), " +
                    "contact VARCHAR(50), " +
                    "address TEXT, " +
                    "user_type VARCHAR(50), " +
                    "date_hired VARCHAR(50), " +
                    "salary DOUBLE, " +
                    "job_title VARCHAR(100), " +
                    "password VARCHAR(100)" +
                    ")");

            // animal_categories table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS animal_categories (" +
                    "name VARCHAR(50) PRIMARY KEY" +
                    ")");

            // animals table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS animals (" +
                    "id VARCHAR(50) PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "gender VARCHAR(20), " +
                    "animal_class VARCHAR(50), " +
                    "ear_tag VARCHAR(50), " +
                    "birth_date VARCHAR(50), " +
                    "color VARCHAR(50), " +
                    "age VARCHAR(50), " +
                    "weight VARCHAR(50), " +
                    "breed VARCHAR(100), " +
                    "pasture VARCHAR(100), " +
                    "category_name VARCHAR(50), " +
                    "FOREIGN KEY (category_name) REFERENCES animal_categories(name) ON DELETE CASCADE ON UPDATE CASCADE" +
                    ")");

            // daily_finance_records table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS daily_finance_records (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "record_date VARCHAR(50) NOT NULL, " +
                    "type VARCHAR(20) NOT NULL, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "expression VARCHAR(200), " +
                    "total DOUBLE NOT NULL" +
                    ")");

            // monthly_profits table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS monthly_profits (" +
                    "month VARCHAR(50) PRIMARY KEY, " +
                    "expression VARCHAR(200), " +
                    "result DOUBLE NOT NULL" +
                    ")");

            // stockfeed_categories table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS stockfeed_categories (" +
                    "name VARCHAR(50) PRIMARY KEY" +
                    ")");

            // stockfeed_items table
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS stockfeed_items (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "category_name VARCHAR(50) NOT NULL, " +
                    "item_name VARCHAR(100) NOT NULL, " +
                    "quantity INT DEFAULT 0, " +
                    "FOREIGN KEY (category_name) REFERENCES stockfeed_categories(name) ON DELETE CASCADE ON UPDATE CASCADE" +
                    ")");

            System.out.println("All relational tables verified/created successfully.");

            // Seed a default admin user if the table is empty
            try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users")) {
                if (rs.next() && rs.getInt(1) == 0) {
                    stmt.executeUpdate("INSERT INTO users (email, password) VALUES ('admin@farm.com', 'admin123')");
                    System.out.println("Default admin user created: admin@farm.com / admin123");
                }
            }

        } catch (SQLException e) {
            System.err.println("Error initializing tables: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
